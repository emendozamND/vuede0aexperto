<script setup>

</script>

<template>
<h1>AboutView</h1>
</template>

<style scoped>

</style>