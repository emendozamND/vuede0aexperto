<script setup>

</script>

<template>
<p>Hola desde  home view</p>
</template>

<style scoped>

</style>