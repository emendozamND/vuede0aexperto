<script setup>

</script>

<template>
<p>Hola desde el LoginView</p>
</template>

<style scoped>

</style>