<script setup>

</script>

<template>
    <p>Hola desde el register view</p>
    
</template>

<style scoped>

</style>